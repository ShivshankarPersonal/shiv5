(function () {
    "use strict";
    angular.module("captchaImagePuzzle", [])
        .directive("captchaImagePuzzle", function ($interval) {
                return {
                    restrict: 'E',
                    templateUrl: 'templates/captchaImagePuzzle.html',
                    link: function ($scope) {
                        $scope.$on("showCaptchaImagePuzzle", function () {
                            var imageID = "img1";
                            var canvasID = "captchaImagePuzzle";
                            var captchaImagePuzzle = null;

                            function LoadGame() {
                                captchaImagePuzzle = new ProveNotRobot(canvasID, imageID);
                                captchaImagePuzzle.initializePuzzleArena();
                            }

                            function imageBlock(no, x, y) {
                                this.no = no;
                                this.x = x;
                                this.y = y;
                                this.isSelected = false;
                            }

                            function ProveNotRobot(canvasID, imageID) {
                                var BLOCK_IMG_WIDTH = 200,
                                    BLOCK_IMG_HEIGHT = 100,
                                // BLOCK_IMG_WIDTH = 400,
                                // BLOCK_IMG_HEIGHT = 250,
                                    MAIN_IMG_WIDTH = BLOCK_IMG_WIDTH + 200,
                                    MAIN_IMG_HEIGHT = BLOCK_IMG_HEIGHT + 200,
                                    TOTAL_ROWS = 2,
                                    TOTAL_COLUMNS = 2,
                                    TOTAL_PIECES = TOTAL_ROWS * TOTAL_COLUMNS,
                                    IMG_WIDTH = Math.round(MAIN_IMG_WIDTH / TOTAL_COLUMNS),
                                    IMG_HEIGHT = Math.round(MAIN_IMG_HEIGHT / TOTAL_ROWS),
                                    BLOCK_WIDTH = Math.round(BLOCK_IMG_WIDTH / TOTAL_COLUMNS),
                                    BLOCK_HEIGHT = Math.round(BLOCK_IMG_HEIGHT / TOTAL_ROWS),
                                    puzzleImage,
                                    canvas,
                                    ctx,
                                    selectedBlock,
                                    randomImageSliceList,
                                    cardboardBlockList;
                                this.initializePuzzleArena = function () {
                                    selectedBlock = null;
                                    canvas = document.getElementById(canvasID);
                                    ctx = canvas.getContext('2d');
                                    canvas.onmousedown = handleOnMouseDown;
                                    canvas.onmouseup = handleOnMouseUp;
                                    canvas.onmouseout = handleOnMouseOut;
                                    canvas.onmousemove = handleOnMouseMove;

                                    canvas.addEventListener("touchstart", handleOnTouchStart, false);
                                    canvas.addEventListener("touchend", handleOnTouchEnd, false);
                                    canvas.addEventListener("touchcancel", handleOnMouseOut, false);
                                    canvas.addEventListener("touchmove", handleOnTouchMove, false);

                                    puzzleImage = document.getElementById(imageID);
                                    initializeNewGame();
                                };
                                function initializeNewGame() {
                                    SetImageBlock();
                                    DrawGame();
                                }

                                function DrawGame() {
                                    clear(ctx);
                                    drawLines();
                                    drawAllImages();
                                    if (selectedBlock) {
                                        drawImageBlock(selectedBlock);
                                    }
                                }

                                function SetImageBlock() {
                                    randomImageSliceList = [];
                                    cardboardBlockList = [];
                                    var x1 = BLOCK_IMG_WIDTH + 20;
                                    var x2 = canvas.width - 50;
                                    var y2 = BLOCK_IMG_HEIGHT;
                                    for (var i = 0; i < TOTAL_PIECES; i++) {
                                        var randomX = randomXtoY(x1, x2, 2);
                                        var randomY = randomXtoY(0, y2, 2);
                                        if (randomY > BLOCK_IMG_HEIGHT - 50) {
                                            randomY = BLOCK_IMG_HEIGHT - 50;
                                        }
                                        // if (randomX > MAIN_IMG_WIDTH + 250) {
                                        //     randomX = MAIN_IMG_WIDTH + 250;
                                        // }
                                        if (randomX > MAIN_IMG_WIDTH) {
                                            randomX = MAIN_IMG_WIDTH - 100;
                                        }
                                        var imgBlock = new imageBlock(i, randomX, randomY);
                                        randomImageSliceList.push(imgBlock);
                                        var x = (i % TOTAL_COLUMNS) * BLOCK_WIDTH;
                                        var y = Math.floor(i / TOTAL_COLUMNS) * BLOCK_HEIGHT;
                                        var block = new imageBlock(i, x, y);
                                        cardboardBlockList.push(block);
                                    }
                                }

                                function drawLines() {
                                    ctx.strokeStyle = "#e9e9e9";
                                    ctx.lineWidth = 2;
                                    ctx.beginPath();
                                    for (var i = 0; i <= TOTAL_COLUMNS; i++) {
                                        var x = BLOCK_WIDTH * i;
                                        ctx.moveTo(x, 0);
                                        ctx.lineTo(x, BLOCK_IMG_HEIGHT);
                                    }
                                    for (var i = 0; i <= TOTAL_ROWS; i++) {
                                        var y = BLOCK_HEIGHT * i;
                                        ctx.moveTo(0, y);
                                        ctx.lineTo(BLOCK_IMG_WIDTH, y);
                                    }
                                    ctx.closePath();
                                    ctx.stroke();
                                }

                                function drawAllImages() {
                                    for (var i = 0; i < randomImageSliceList.length; i++) {
                                        var imgBlock = randomImageSliceList[i];
                                        if (imgBlock.isSelected == false) {
                                            drawImageBlock(imgBlock);
                                        }
                                    }
                                }

                                function drawImageBlock(imgBlock) {
                                    drawFinalImage(imgBlock.no, imgBlock.x, imgBlock.y, BLOCK_WIDTH, BLOCK_HEIGHT);
                                }

                                // Redrawing animated images if user fails to  complete puzzle
                                function drawFinalImage(index, destX, destY, destWidth, destHeight) {
                                    ctx.save();
                                    var srcX = (index % TOTAL_COLUMNS) * IMG_WIDTH;
                                    var srcY = Math.floor(index / TOTAL_COLUMNS) * IMG_HEIGHT;
                                    ctx.drawImage(puzzleImage, srcX, srcY, IMG_WIDTH, IMG_HEIGHT, destX, destY, destWidth, destHeight);
                                    ctx.restore();
                                }

                                var interval = null;

                                function OnFinished() {
                                    $scope.congratulations = true;
                                    if (!$scope.$$phase) {
                                        $scope.$apply();
                                    }
                                    $scope.$emit("successfullySolvedPuzzle", {});
                                }

                                // EVENTS Listeners
                                function getTouchPos(canvasDom, touchEvent) {
                                    if (touchEvent && touchEvent.touches && touchEvent.touches[0]) {
                                        var rect = canvasDom.getBoundingClientRect();
                                        return {
                                            x: touchEvent.touches[0].clientX - rect.left,
                                            y: touchEvent.touches[0].clientY - rect.top
                                        };
                                    }
                                }

                                function handleOnTouchStart(e) {
                                    if (e.touches[0]) {
                                        var mousePosition = getTouchPos(canvas, e);
                                        console.log(mousePosition);
                                        if (selectedBlock != null) {
                                            randomImageSliceList[selectedBlock.no].isSelected = false;
                                        }
                                        selectedBlock = GetImageBlock(randomImageSliceList, mousePosition.x, mousePosition.y);
                                        if (selectedBlock) {
                                            randomImageSliceList[selectedBlock.no].isSelected = true;
                                        }
                                        if (e.target == canvas) {
                                            e.preventDefault();
                                        }
                                    }
                                }

                                function getTouchPositionAfterTouchEnd(canvasDom, e) {
                                    var rect = canvasDom.getBoundingClientRect();
                                    return {
                                        x: e.changedTouches[0].clientX - rect.left,
                                        y: e.changedTouches[0].clientY - rect.top
                                    };
                                }

                                function handleOnTouchEnd(e) {
                                    var mousePosition = getTouchPositionAfterTouchEnd(canvas, e);
                                    console.log(mousePosition);
                                    if (selectedBlock) {
                                        var index = selectedBlock.no;
                                        var cardSlot = GetImageBlock(cardboardBlockList, mousePosition.x, mousePosition.y);
                                        if (cardSlot) {
                                            var blockOldImage = GetImageBlockOnEqual(randomImageSliceList, cardSlot.x, cardSlot.y);
                                            if (blockOldImage == null) {
                                                randomImageSliceList[index].x = cardSlot.x;
                                                randomImageSliceList[index].y = cardSlot.y;
                                            }
                                        }
                                        else {
                                            randomImageSliceList[index].x = selectedBlock.x;
                                            randomImageSliceList[index].y = selectedBlock.y;
                                        }
                                        randomImageSliceList[index].isSelected = false;
                                        selectedBlock = null;
                                        DrawGame();
                                        if (isFinished()) {
                                            OnFinished();
                                        }
                                    }
                                    if (e.target == canvas) {
                                        e.preventDefault();
                                    }
                                }

                                function handleOnTouchMove(e) {
                                    if (e.touches[0]) {
                                        var mousePosition = getTouchPos(canvas, e);
                                        console.log(mousePosition);
                                        if (selectedBlock) {
                                            selectedBlock.x = mousePosition.x - 25;
                                            selectedBlock.y = mousePosition.y - 25;
                                            DrawGame();
                                        }
                                        if (e.target == canvas) {
                                            e.preventDefault();
                                        }
                                    }
                                }

                                function handleOnMouseOut(e) {
                                    if (selectedBlock != null) {
                                        randomImageSliceList[selectedBlock.no].isSelected = false;
                                        selectedBlock = null;
                                        DrawGame();
                                    }
                                    if (e.target == canvas) {
                                        e.preventDefault();
                                    }
                                }

                                function handleOnMouseDown(e) {
                                    var mousePos = getTouchPos(canvas, e);
                                    console.log(mousePos)
                                    if (selectedBlock != null) {
                                        randomImageSliceList[selectedBlock.no].isSelected = false;
                                    }
                                    selectedBlock = GetImageBlock(randomImageSliceList, e.layerX, e.layerY);
                                    if (selectedBlock) {
                                        randomImageSliceList[selectedBlock.no].isSelected = true;
                                    }
                                }

                                function handleOnMouseUp(e) {
                                    if (selectedBlock) {
                                        var index = selectedBlock.no;
                                        var cardSlot = GetImageBlock(cardboardBlockList, e.layerX, e.layerY);
                                        if (cardSlot) {
                                            var blockOldImage = GetImageBlockOnEqual(randomImageSliceList, cardSlot.x, cardSlot.y);
                                            if (blockOldImage == null) {
                                                randomImageSliceList[index].x = cardSlot.x;
                                                randomImageSliceList[index].y = cardSlot.y;
                                            }
                                        }
                                        else {
                                            randomImageSliceList[index].x = selectedBlock.x;
                                            randomImageSliceList[index].y = selectedBlock.y;
                                        }
                                        randomImageSliceList[index].isSelected = false;
                                        selectedBlock = null;
                                        DrawGame();
                                        if (isFinished()) {
                                            OnFinished();
                                        }
                                    }
                                }

                                function handleOnMouseMove(e) {
                                    if (selectedBlock) {
                                        selectedBlock.x = e.layerX - 25;
                                        selectedBlock.y = e.layerY - 25;
                                        DrawGame();
                                    }
                                }

                                // Utilities
                                function clear(c) {
                                    c.clearRect(0, 0, canvas.width, canvas.height);
                                }

                                function randomXtoY(minVal, maxVal, floatVal) {
                                    var randVal = minVal + (Math.random() * (maxVal - minVal));
                                    var val = typeof floatVal == 'undefined' ? Math.round(randVal) : randVal.toFixed(floatVal);
                                    return Math.round(val);
                                }

                                function GetImageBlock(list, x, y) {
                                    for (var i = list.length - 1; i >= 0; i--) {
                                        var imgBlock = list[i];
                                        var x1 = imgBlock.x;
                                        var x2 = x1 + BLOCK_WIDTH;
                                        var y1 = imgBlock.y;
                                        var y2 = y1 + BLOCK_HEIGHT;
                                        if (
                                            (x >= x1 && x <= x2) &&
                                            (y >= y1 && y <= y2)
                                        ) {
                                            var img = new imageBlock(imgBlock.no, imgBlock.x, imgBlock.y);
                                            return img;
                                        }
                                    }
                                    return null;
                                }

                                function GetImageBlockOnEqual(list, x, y) {
                                    for (var i = 0; i < list.length; i++) {
                                        var imgBlock = list[i];
                                        var x1 = imgBlock.x;
                                        var y1 = imgBlock.y;
                                        if (
                                            (x == x1) &&
                                            (y == y1)
                                        ) {
                                            var img = new imageBlock(imgBlock.no, imgBlock.x, imgBlock.y);
                                            return img;
                                        }
                                    }
                                    return null;
                                }

                                function isFinished() {
                                    for (var i = 0; i < TOTAL_PIECES; i++) {
                                        var img = randomImageSliceList[i];
                                        var block = cardboardBlockList[i];
                                        if (
                                            (img.x != block.x) ||
                                            (img.y != block.y)
                                        ) {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }

                            LoadGame();
                            $scope.$on("reloadNextImage", function () {
                                LoadGame();
                            });
                        });
                    }
                }
            }
        )
})();
